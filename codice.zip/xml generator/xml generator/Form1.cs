﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.IO;
using System.Threading;
using System.Globalization;

namespace xml_generator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }


        //Code to close and minimize the window
        private void Button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        //Code to make the form draggable

        Point lastPoint; 

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }


        //inzio codice per verificare che ciò che inserisco nelle textbox sia un numero (con punto e non virgola)
        //questi frammenti di codice si attivano quando il 
        

        private void TextBox2_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox2.Text, "[^0-9-.]"))
            {
                MessageBox.Show("Perfavore, inserisci solo numeri ed usa il punto.");
                textBox2.Text = textBox2.Text.Remove(textBox2.Text.Length - 1);
            }
        }

        private void TextBox3_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox3.Text, "[^0-9-.]"))
            {
                MessageBox.Show("Perfavore, inserisci solo numeri ed usa il punto.");
                textBox3.Text = textBox3.Text.Remove(textBox3.Text.Length - 1);
            }
        }

        private void TextBox4_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox4.Text, "[^0-9-.]"))
            {
                MessageBox.Show("Perfavore, inserisci solo numeri ed usa il punto.");
                textBox4.Text = textBox4.Text.Remove(textBox4.Text.Length - 1);
            }
        }
         private void TextBox5_TextChanged(object sender, EventArgs e)
                {
                    if (System.Text.RegularExpressions.Regex.IsMatch(textBox5.Text, "[^0-9-.]"))
                    {
                        MessageBox.Show("Perfavore, inserisci solo numeri ed usa il punto.");
                        textBox5.Text = textBox5.Text.Remove(textBox5.Text.Length - 1);
                    }
                }





        //Xml file creation
        private void Button3_Click(object sender, EventArgs e)
        {
            int intValue = 0;
            int intValue1 = 0;
            int intValue2 = 0;

            bool sblocco = false;
            bool leap = false;

            string currentYear = DateTime.Now.Year.ToString();
            string currentMonth = DateTime.Now.Month.ToString();
            string currentDay = DateTime.Now.Day.ToString();
            string currentHour = DateTime.Now.Hour.ToString();
            string currentMinute = DateTime.Now.Minute.ToString();
            string currentSecond = DateTime.Now.Second.ToString();

            if (string.IsNullOrEmpty(textBox9.Text))
            {
                textBox9.Text = currentYear;
            }
            if (string.IsNullOrEmpty(textBox8.Text))
            {
                textBox8.Text = currentMonth;
            }
            if (string.IsNullOrEmpty(textBox7.Text))
            {
                textBox7.Text = currentDay;
            }

            if (string.IsNullOrEmpty(textBox10.Text))
            {
                textBox10.Text = currentHour;
            }
            if (string.IsNullOrEmpty(textBox11.Text))
            {
                textBox11.Text = currentMinute;
            }
            if (string.IsNullOrEmpty(textBox42.Text))
            {
                textBox42.Text = currentSecond;
            }


            Int32.TryParse(textBox7.Text, out intValue);
            Int32.TryParse(textBox8.Text, out intValue1);
            Int32.TryParse(textBox9.Text, out intValue2);

            if (DateTime.IsLeapYear(intValue2))
            {
                leap = true;
            }
            else
            {
                leap = false;
            }
           

            if (intValue > 31 || intValue < 0)
            {
                textBox7.Text = "";
                MessageBox.Show("Giorni massimi 31");
                sblocco = false;
            }
            else if (intValue1 > 12 || intValue1 < 0)
            {
                textBox8.Text = "";
                MessageBox.Show("Mesi massimi 12");
                sblocco = false;
            }

            else if (intValue2 < 0)
            {
                textBox9.Text = "";
                sblocco = false;
            }

            else if (intValue1 == 2 && (intValue == 29  && leap == true))
            {
                sblocco = true;
            }
            else if(intValue1 == 2 && (intValue == 29 && leap == false))
            {
                sblocco = false;
                textBox7.Text = "";
                MessageBox.Show("Non è un anno bisestile");

            }
            else if (intValue1 == 2 && intValue > 29)
            {
                sblocco = false;
                textBox7.Text = "";
                MessageBox.Show("Giorni massimi 28 (29 se bisestile)");

            }
            else if (intValue1 == 1 || intValue1 == 3 || intValue1 == 5 || intValue1 == 7 || intValue1 == 8 || intValue1 == 10 || intValue1 == 12)
            {
                sblocco = true;
            }
            else if (intValue1 !=2 && intValue > 30)
            {
                MessageBox.Show("Data errata! Max 30 gg");
                textBox7.Text = "";
                sblocco = false;
            }
            else
            {
                sblocco = true;
            }


            if (sblocco)
            {

                
                if (string.IsNullOrEmpty(textBox49.Text))
                {
                    textBox49.Text = "0";
                }
                if (string.IsNullOrEmpty(textBox50.Text))
                {
                    textBox50.Text = "0";
                }
                if (string.IsNullOrEmpty(textBox51.Text))
                {
                    textBox51.Text = "0";
                }
                if (string.IsNullOrEmpty(textBox52.Text))
                {
                    textBox52.Text = "0";
                }
                if (string.IsNullOrEmpty(textBox2.Text))
                {
                    textBox2.Text = "0";
                }
                
                if (string.IsNullOrEmpty(textBox14.Text))
                {
                    textBox14.Text = "0";
                }               
                if (string.IsNullOrEmpty(textBox20.Text))
                {
                    textBox20.Text = "0";
                }
                
                if (string.IsNullOrEmpty(textBox17.Text))
                {
                    textBox17.Text = "0";
                }
                
                if (string.IsNullOrEmpty(textBox26.Text))
                {
                    textBox26.Text = "0";
                }
                
                if (string.IsNullOrEmpty(textBox23.Text))
                {
                    textBox23.Text = "0";
                }
               
                if (string.IsNullOrEmpty(textBox32.Text))
                {
                    textBox32.Text = "0";
                }
                
                if (string.IsNullOrEmpty(textBox29.Text))
                {
                    textBox29.Text = "0";
                }
               
                if (string.IsNullOrEmpty(textBox38.Text))
                {
                    textBox38.Text = "0";
                }
                
                if (string.IsNullOrEmpty(textBox35.Text))
                {
                    textBox35.Text = "0";
                }
                
                
                
                XmlWriter writer = null;
                string filename = textBox6.Text + ".xml";
                string data = textBox9.Text + "-" + textBox8.Text + "-" + textBox7.Text + "T" + textBox10.Text + ":" + textBox11.Text + ":" + textBox42.Text;


                XmlWriterSettings settings = new XmlWriterSettings();
                settings.Indent = true;
                settings.IndentChars = ("    ");
                settings.CloseOutput = true;
                settings.OmitXmlDeclaration = true;
                settings.Encoding = Encoding.GetEncoding("ISO-8859-1");

                if (File.Exists(filename))
                {
                    MessageBox.Show("Perfavore usa un nome diverso per la creazione del file");
                }
                else
                {
                    writer = XmlWriter.Create(filename, settings);

                    writer.WriteStartElement("DatiCorrispettivi");

                    writer.WriteStartElement("Trasmissione");

                    writer.WriteElementString("Progressivo", textBox5.Text);
                    writer.WriteElementString("Formato", "COR10");

                    writer.WriteEndElement();

                    writer.WriteElementString("DataOraRilevazione", data);

                    writer.WriteStartElement("DataRT");


                    //aliquota 22% inizio
                    writer.WriteStartElement("Riepilogo");
                    writer.WriteStartElement("IVA");

                    writer.WriteElementString("AliquotaIVA", "22.00");                    
                    writer.WriteElementString("Imposta", textBox52.Text);

                    writer.WriteEndElement();

                    writer.WriteElementString("Ammontare", textBox2.Text);
                    if (!string.IsNullOrEmpty(textBox3.Text))
                    {
                        writer.WriteElementString("TotaleAmmontareResi", textBox3.Text);
                    }
                    if (!string.IsNullOrEmpty(textBox4.Text))
                    {
                        writer.WriteElementString("TotaleAmmontareAnnulli", textBox4.Text);
                    }
                    writer.WriteEndElement();

                    //aliquota 10% inizio

                    writer.WriteStartElement("Riepilogo");
                    writer.WriteStartElement("IVA");

                    writer.WriteElementString("AliquotaIVA", "10.00");
                    writer.WriteElementString("Imposta", textBox51.Text);

                    writer.WriteEndElement();

                    writer.WriteElementString("Ammontare", textBox14.Text);
                    if (!string.IsNullOrEmpty(textBox13.Text))
                    {
                        writer.WriteElementString("TotaleAmmontareResi", textBox13.Text);
                    }
                    if (!string.IsNullOrEmpty(textBox12.Text))
                    {
                        writer.WriteElementString("TotaleAmmontareAnnulli", textBox12.Text);
                    }
                    writer.WriteEndElement();

                    //aliquota 4% inizio

                    writer.WriteStartElement("Riepilogo");
                    writer.WriteStartElement("IVA");

                    writer.WriteElementString("AliquotaIVA", "4.00");
                    writer.WriteElementString("Imposta", textBox49.Text);

                    writer.WriteEndElement();

                    writer.WriteElementString("Ammontare", textBox17.Text);
                    if (!string.IsNullOrEmpty(textBox16.Text))
                    {
                        writer.WriteElementString("TotaleAmmontareResi", textBox16.Text);
                    }
                    if (!string.IsNullOrEmpty(textBox15.Text))
                    {
                        writer.WriteElementString("TotaleAmmontareAnnulli", textBox15.Text);
                    }
                    writer.WriteEndElement();

                    //aliquota 5% inizio

                    writer.WriteStartElement("Riepilogo");
                    writer.WriteStartElement("IVA");

                    writer.WriteElementString("AliquotaIVA", "5.00");
                    writer.WriteElementString("Imposta", textBox50.Text);

                    writer.WriteEndElement();

                    writer.WriteElementString("Ammontare", textBox20.Text);
                    if (!string.IsNullOrEmpty(textBox19.Text))
                    {
                        writer.WriteElementString("TotaleAmmontareResi", textBox19.Text);
                    }
                    if (!string.IsNullOrEmpty(textBox18.Text))
                    {
                        writer.WriteElementString("TotaleAmmontareAnnulli", textBox18.Text);
                    }
                    writer.WriteEndElement();

                    

                    //aliquota N1 inizio


                    writer.WriteStartElement("Riepilogo");
                    

                    writer.WriteElementString("Natura", "N1");
                   // writer.WriteElementString("Imposta", textBox48.Text);

                    

                    writer.WriteElementString("Ammontare", textBox26.Text);
                    if (!string.IsNullOrEmpty(textBox25.Text))
                    {
                        writer.WriteElementString("TotaleAmmontareResi", textBox25.Text);
                    }
                    if (!string.IsNullOrEmpty(textBox24.Text))
                    {
                        writer.WriteElementString("TotaleAmmontareAnnulli", textBox24.Text);
                    }
                    writer.WriteEndElement();
                    
                    

                    //aliquota N2 inizio


                    writer.WriteStartElement("Riepilogo");
                    

                    writer.WriteElementString("Natura", "N2");
                    //writer.WriteElementString("Imposta", textBox47.Text);

                    

                    writer.WriteElementString("Ammontare", textBox23.Text);
                    if (!string.IsNullOrEmpty(textBox25.Text))
                    {
                        writer.WriteElementString("TotaleAmmontareResi", textBox25.Text);
                    }
                    if (!string.IsNullOrEmpty(textBox21.Text))
                    {
                        writer.WriteElementString("TotaleAmmontareAnnulli", textBox21.Text);
                    }
                    writer.WriteEndElement();
                    

                    //aliquota N3 inizio


                    writer.WriteStartElement("Riepilogo");

                    writer.WriteElementString("Natura", "N3");
                   // writer.WriteElementString("Imposta", textBox46.Text);

                   

                    writer.WriteElementString("Ammontare", textBox32.Text);
                    if (!string.IsNullOrEmpty(textBox31.Text))
                    {
                        writer.WriteElementString("TotaleAmmontareResi", textBox31.Text);
                    }
                    if (!string.IsNullOrEmpty(textBox30.Text))
                    {
                        writer.WriteElementString("TotaleAmmontareAnnulli", textBox30.Text);
                    }
                    writer.WriteEndElement();

                    //aliquota N4 inizio


                    writer.WriteStartElement("Riepilogo");

                    writer.WriteElementString("Natura", "N4");
                   // writer.WriteElementString("Imposta", textBox45.Text);

                    

                    writer.WriteElementString("Ammontare", textBox29.Text);
                    if (!string.IsNullOrEmpty(textBox28.Text))
                    {
                        writer.WriteElementString("TotaleAmmontareResi", textBox28.Text);
                    }
                    if (!string.IsNullOrEmpty(textBox27.Text))
                    {
                        writer.WriteElementString("TotaleAmmontareAnnulli", textBox27.Text);
                    }
                    writer.WriteEndElement();
                    

                    //aliquota N5 inizio


                    writer.WriteStartElement("Riepilogo");

                    writer.WriteElementString("Natura", "N5");
                   // writer.WriteElementString("Imposta", textBox44.Text);

                    

                    writer.WriteElementString("Ammontare", textBox38.Text);
                    if (!string.IsNullOrEmpty(textBox37.Text))
                    {
                        writer.WriteElementString("TotaleAmmontareResi", textBox37.Text);
                    }
                    if (!string.IsNullOrEmpty(textBox36.Text))
                    {
                        writer.WriteElementString("TotaleAmmontareAnnulli", textBox36.Text);
                    }
                    writer.WriteEndElement();

                    //aliquota N6 inizio


                    writer.WriteStartElement("Riepilogo");

                    writer.WriteElementString("Natura", "N6");
                   // writer.WriteElementString("Imposta", textBox43.Text);

                   

                    writer.WriteElementString("Ammontare", textBox35.Text);
                    if (!string.IsNullOrEmpty(textBox34.Text))
                    {
                        writer.WriteElementString("TotaleAmmontareResi", textBox34.Text);
                    }
                    if (!string.IsNullOrEmpty(textBox33.Text))
                    {
                        writer.WriteElementString("TotaleAmmontareAnnulli", textBox33.Text);
                    }
                    writer.WriteEndElement();
                                                                              


                    //fine elements
                    writer.WriteEndElement();
                    writer.WriteEndElement();

                    writer.Flush();
                    writer.Close();
                }
            }                    

        }

        private void ClearTextBoxes()
        {
            Action<Control.ControlCollection> func = null;

            func = (controls) =>
            {
                foreach (Control control in controls)
                    if (control is TextBox)
                        (control as TextBox).Clear();
                    else
                        func(control.Controls);
            };

            func(Controls);
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            ClearTextBoxes();
        }

        private void TextBox7_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox7.Text, "[^0-9]"))
            {
                MessageBox.Show("Perfavore, inserisci solo numeri");
                textBox7.Text = textBox7.Text.Remove(textBox7.Text.Length - 1);
            }             
        }

        private void TextBox52_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox52.Text, "[^0-9-.]"))
            {
                MessageBox.Show("Perfavore, inserisci solo numeri ed usa il punto.");
                textBox52.Text = textBox52.Text.Remove(textBox52.Text.Length - 1);
            }
        }

        private void TextBox51_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox51.Text, "[^0-9-.]"))
            {
                MessageBox.Show("Perfavore, inserisci solo numeri ed usa il punto.");
                textBox51.Text = textBox51.Text.Remove(textBox51.Text.Length - 1);
            }
        }

        private void TextBox14_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox14.Text, "[^0-9-.]"))
            {
                MessageBox.Show("Perfavore, inserisci solo numeri ed usa il punto.");
                textBox14.Text = textBox14.Text.Remove(textBox14.Text.Length - 1);
            }
        }

        private void TextBox13_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox13.Text, "[^0-9-.]"))
            {
                MessageBox.Show("Perfavore, inserisci solo numeri ed usa il punto.");
                textBox13.Text = textBox13.Text.Remove(textBox13.Text.Length - 1);
            }
        }

        private void TextBox12_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox12.Text, "[^0-9-.]"))
            {
                MessageBox.Show("Perfavore, inserisci solo numeri ed usa il punto.");
                textBox12.Text = textBox12.Text.Remove(textBox12.Text.Length - 1);
            }
        }

        private void TextBox50_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox50.Text, "[^0-9-.]"))
            {
                MessageBox.Show("Perfavore, inserisci solo numeri ed usa il punto.");
                textBox50.Text = textBox50.Text.Remove(textBox50.Text.Length - 1);
            }
        }

        private void TextBox20_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox20.Text, "[^0-9-.]"))
            {
                MessageBox.Show("Perfavore, inserisci solo numeri ed usa il punto.");
                textBox20.Text = textBox20.Text.Remove(textBox20.Text.Length - 1);
            }
        }

        private void TextBox19_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox19.Text, "[^0-9-.]"))
            {
                MessageBox.Show("Perfavore, inserisci solo numeri ed usa il punto.");
                textBox19.Text = textBox19.Text.Remove(textBox19.Text.Length - 1);
            }
        }

        private void TextBox18_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox18.Text, "[^0-9-.]"))
            {
                MessageBox.Show("Perfavore, inserisci solo numeri ed usa il punto.");
                textBox18.Text = textBox18.Text.Remove(textBox18.Text.Length - 1);
            }
        }

        private void TextBox49_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox49.Text, "[^0-9-.]"))
            {
                MessageBox.Show("Perfavore, inserisci solo numeri ed usa il punto.");
                textBox49.Text = textBox49.Text.Remove(textBox49.Text.Length - 1);
            }
        }

        private void TextBox17_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox17.Text, "[^0-9-.]"))
            {
                MessageBox.Show("Perfavore, inserisci solo numeri ed usa il punto.");
                textBox17.Text = textBox17.Text.Remove(textBox17.Text.Length - 1);
            }
        }

        private void TextBox16_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox16.Text, "[^0-9-.]"))
            {
                MessageBox.Show("Perfavore, inserisci solo numeri ed usa il punto.");
                textBox16.Text = textBox16.Text.Remove(textBox16.Text.Length - 1);
            }
        }

        private void TextBox15_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox15.Text, "[^0-9-.]"))
            {
                MessageBox.Show("Perfavore, inserisci solo numeri ed usa il punto.");
                textBox15.Text = textBox15.Text.Remove(textBox15.Text.Length - 1);
            }
        }

        
        private void TextBox26_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox26.Text, "[^0-9-.]"))
            {
                MessageBox.Show("Perfavore, inserisci solo numeri ed usa il punto.");
                textBox26.Text = textBox26.Text.Remove(textBox26.Text.Length - 1);
            }
        }

        private void TextBox25_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox25.Text, "[^0-9-.]"))
            {
                MessageBox.Show("Perfavore, inserisci solo numeri ed usa il punto.");
                textBox25.Text = textBox25.Text.Remove(textBox25.Text.Length - 1);
            }
        }

        private void TextBox24_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox24.Text, "[^0-9-.]"))
            {
                MessageBox.Show("Perfavore, inserisci solo numeri ed usa il punto.");
                textBox24.Text = textBox24.Text.Remove(textBox24.Text.Length - 1);
            }
        }

        

        private void TextBox23_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox23.Text, "[^0-9-.]"))
            {
                MessageBox.Show("Perfavore, inserisci solo numeri ed usa il punto.");
                textBox23.Text = textBox23.Text.Remove(textBox23.Text.Length - 1);
            }
        }

        private void TextBox22_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox22.Text, "[^0-9-.]"))
            {
                MessageBox.Show("Perfavore, inserisci solo numeri ed usa il punto.");
                textBox22.Text = textBox22.Text.Remove(textBox22.Text.Length - 1);
            }
        }

        private void TextBox21_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox21.Text, "[^0-9-.]"))
            {
                MessageBox.Show("Perfavore, inserisci solo numeri ed usa il punto.");
                textBox21.Text = textBox21.Text.Remove(textBox21.Text.Length - 1);
            }
        }

       

        private void TextBox32_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox32.Text, "[^0-9-.]"))
            {
                MessageBox.Show("Perfavore, inserisci solo numeri ed usa il punto.");
                textBox32.Text = textBox32.Text.Remove(textBox32.Text.Length - 1);
            }
        }

        private void TextBox31_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox31.Text, "[^0-9-.]"))
            {
                MessageBox.Show("Perfavore, inserisci solo numeri ed usa il punto.");
                textBox31.Text = textBox31.Text.Remove(textBox31.Text.Length - 1);
            }
        }

        private void TextBox30_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox30.Text, "[^0-9-.]"))
            {
                MessageBox.Show("Perfavore, inserisci solo numeri ed usa il punto.");
                textBox30.Text = textBox30.Text.Remove(textBox30.Text.Length - 1);
            }
        }

        

        private void TextBox29_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox29.Text, "[^0-9-.]"))
            {
                MessageBox.Show("Perfavore, inserisci solo numeri ed usa il punto.");
                textBox29.Text = textBox29.Text.Remove(textBox29.Text.Length - 1);
            }
        }

        private void TextBox28_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox28.Text, "[^0-9-.]"))
            {
                MessageBox.Show("Perfavore, inserisci solo numeri ed usa il punto.");
                textBox28.Text = textBox28.Text.Remove(textBox28.Text.Length - 1);
            }
        }

        private void TextBox27_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox27.Text, "[^0-9-.]"))
            {
                MessageBox.Show("Perfavore, inserisci solo numeri ed usa il punto.");
                textBox27.Text = textBox27.Text.Remove(textBox27.Text.Length - 1);
            }
        }

        

        private void TextBox38_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox38.Text, "[^0-9-.]"))
            {
                MessageBox.Show("Perfavore, inserisci solo numeri ed usa il punto.");
                textBox38.Text = textBox38.Text.Remove(textBox38.Text.Length - 1);
            }
        }

        private void TextBox37_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox37.Text, "[^0-9-.]"))
            {
                MessageBox.Show("Perfavore, inserisci solo numeri ed usa il punto.");
                textBox37.Text = textBox37.Text.Remove(textBox37.Text.Length - 1);
            }
        }

        private void TextBox36_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox36.Text, "[^0-9-.]"))
            {
                MessageBox.Show("Perfavore, inserisci solo numeri ed usa il punto.");
                textBox36.Text = textBox36.Text.Remove(textBox36.Text.Length - 1);
            }
        }

        

        private void TextBox35_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox35.Text, "[^0-9-.]"))
            {
                MessageBox.Show("Perfavore, inserisci solo numeri ed usa il punto.");
                textBox35.Text = textBox35.Text.Remove(textBox35.Text.Length - 1);
            }
        }

        private void TextBox34_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox34.Text, "[^0-9-.]"))
            {
                MessageBox.Show("Perfavore, inserisci solo numeri ed usa il punto.");
                textBox34.Text = textBox34.Text.Remove(textBox34.Text.Length - 1);
            }
        }

        private void TextBox33_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox33.Text, "[^0-9-.]"))
            {
                MessageBox.Show("Perfavore, inserisci solo numeri ed usa il punto.");
                textBox33.Text = textBox33.Text.Remove(textBox33.Text.Length - 1);
            }
        }

        
        private void TextBox8_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox8.Text, "[^0-9]"))
            {
                MessageBox.Show("Perfavore, inserisci solo numeri ed usa il punto.");
                textBox8.Text = textBox8.Text.Remove(textBox8.Text.Length - 1);
            }

            int intValue = 0;
            int intValue1 = 0;

            Int32.TryParse(textBox8.Text, out intValue);
            Int32.TryParse(textBox7.Text, out intValue1);

            
        }

        private void TextBox9_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox9.Text, "[^0-9]"))
            {
                MessageBox.Show("Perfavore, inserisci solo numeri");
                textBox9.Text = textBox9.Text.Remove(textBox9.Text.Length - 1);
            }
        }

        private void TextBox10_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox10.Text, "[^0-9]"))
            {
                MessageBox.Show("Perfavore, inserisci solo numeri ed usa il punto.");
                textBox10.Text = textBox10.Text.Remove(textBox10.Text.Length - 1);
            }

            int intValue = 0;

            Int32.TryParse(textBox10.Text, out intValue);
            if (intValue > 23)
            {
                textBox10.Text = "";
            }
        }

        private void TextBox11_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox11.Text, "[^0-9]"))
            {
                MessageBox.Show("Perfavore, inserisci solo numeri.");
                textBox11.Text = textBox11.Text.Remove(textBox11.Text.Length - 1);
            }

            int intValue = 0;

            Int32.TryParse(textBox11.Text, out intValue);
            if (intValue > 59)
            {
                textBox11.Text = "";
            }
        }

        private void TextBox42_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox42.Text, "[^0-9]"))
            {
                MessageBox.Show("Perfavore, inserisci solo numeri.");
                textBox42.Text = textBox42.Text.Remove(textBox42.Text.Length - 1);
            }

            int intValue = 0;

            Int32.TryParse(textBox42.Text, out intValue);
            if (intValue > 59)
            {
                textBox42.Text = "";
            } 
        }

        private void TextBox7_MouseLeave(object sender, EventArgs e)
        {

        }
    }
}
